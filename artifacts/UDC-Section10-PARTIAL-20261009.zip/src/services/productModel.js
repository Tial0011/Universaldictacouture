/**
 * Product model.
 *
 * Firestore documents are author-facing and will grow as the admin
 * tools are built, so every read passes through here and the rest of
 * the app only ever sees this normalised shape. Anything that fails
 * the publishing-completeness rules is dropped rather than shown with
 * invented data.
 */

import { normaliseText } from "../utils/search.js";

/** Taxonomy dimensions the Shop filters on. */
export const FILTER_DIMENSIONS = [
  { key: "category", label: "Category" },
  { key: "occasion", label: "Occasion" },
  { key: "style", label: "Style" },
  { key: "fabric", label: "Fabric & Pattern" },
  { key: "colour", label: "Colour" },
];

function toArray(value) {
  if (Array.isArray(value)) return value.filter(Boolean).map(String);
  if (value === 0) return ["0"];
  if (!value) return [];
  return [String(value)];
}

function toNumber(value) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "") {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : null;
  }
  return null;
}

function toDate(value) {
  if (!value) return null;
  if (typeof value?.toDate === "function") return value.toDate();
  if (value instanceof Date) return value;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function normaliseImage(image) {
  if (!image) return null;
  if (typeof image === "string") return { url: image, publicId: "", alt: "" };
  const url = image.url || image.secureUrl || image.secure_url || "";
  const publicId = image.publicId || image.public_id || "";
  if (!url && !publicId) return null;
  return { url, publicId, alt: image.alt || "" };
}

function normaliseOptions(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .map((option, index) => {
      const name = option?.name ? String(option.name) : "";
      const values = toArray(option?.values);
      if (!name || values.length === 0) return null;
      return {
        id: option?.id ? String(option.id) : `option-${index}`,
        name,
        values,
        required: option?.required !== false,
      };
    })
    .filter(Boolean);
}

function normaliseVariants(raw) {
  return (Array.isArray(raw) ? raw : [])
    .map((variant) => {
      const price = toNumber(variant?.price);
      if (price === null || price < 0) return null;
      return {
        id: variant?.id ? String(variant.id) : "",
        price,
        options: variant?.options && typeof variant.options === "object" ? variant.options : {},
      };
    })
    .filter(Boolean);
}

/**
 * Convert a raw Firestore document into the shape the UI uses.
 * Returns null when the document is not publishable.
 */
export function normaliseProduct(id, raw) {
  if (!raw || typeof raw !== "object") return null;

  const status = String(raw.status ?? (raw.published ? "published" : "")).toLowerCase();
  const isPublished = status === "published" && raw.archived !== true;
  if (!isPublished) return null;

  const name = typeof raw.name === "string" ? raw.name.trim() : "";
  if (!name) return null;

  const slug = String(raw.slug || id || "").trim();
  if (!slug) return null;

  const imageSource = Array.isArray(raw.images) ? raw.images : raw.images ? [raw.images] : [];
  const images = imageSource.map(normaliseImage).filter(Boolean);
  // A piece with no uploaded photo stays publishable with an empty
  // media frame; never substitute a photograph of another product.
  const primaryImage = normaliseImage(raw.primaryImage) || images[0] || null;
  // Section 4 public completeness gate: an eligible published piece must
  // have a real primary image. A configured image that later fails to load
  // is handled by ProductImage's branded fallback without fabricating media.
  if (!primaryImage) return null;

  const options = normaliseOptions(raw.options);
  const variants = normaliseVariants(raw.variants);

  const basePrice = toNumber(raw.price);
  const variantPrices = variants.map((variant) => variant.price);
  const prices = [basePrice, ...variantPrices].filter(
    (price) => typeof price === "number" && price >= 0
  );
  if (!prices.length) return null;

  const category = toArray(raw.category ?? raw.categories);
  if (!category.length) return null;

  // Single fixed main price: if multiple prices exist (e.g. lower/higher for different kedas or bundles),
  // delete the lower price and let the higher price be the main price.
  const mainPrice = Math.max(...prices);
  const unitLabel = typeof (raw.unitLabel ?? raw.priceToken) === "string"
    ? (raw.unitLabel ?? raw.priceToken).trim()
    : "";
  // Section 4 cards must communicate a truthful commercial basis alongside
  // price. Legacy published records with no configured unit are incomplete
  // public catalogue data and stay out of the customer Shop until corrected.
  if (!unitLabel) return null;

  const rawShopBy = raw.shopBy && typeof raw.shopBy === "object" && !Array.isArray(raw.shopBy) ? raw.shopBy : {};
  const shopBy = Object.fromEntries(
    Object.entries(rawShopBy)
      .map(([key, values]) => [String(key).trim(), toArray(values)])
      .filter(([key, values]) => key && values.length)
  );
  const legacyShopBy = {
    occasion: toArray(raw.occasion ?? raw.occasions),
    style: toArray(raw.style ?? raw.styles),
    fabric: toArray(raw.fabric ?? raw.weave ?? raw.fabrics),
  };
  Object.entries(legacyShopBy).forEach(([key, values]) => {
    const merged = [...(shopBy[key] ?? []), ...values];
    const seen = new Set();
    const unique = merged.filter((value) => {
      const normalised = String(value).trim().toLowerCase();
      if (!normalised || seen.has(normalised)) return false;
      seen.add(normalised);
      return true;
    });
    if (unique.length) shopBy[key] = unique;
  });

  const product = {
    id,
    slug,
    name,
    description: typeof raw.description === "string" ? raw.description.trim() : "",
    href: `/shop/${encodeURIComponent(slug)}`,
    image: primaryImage,
    images: images.length ? images : primaryImage ? [primaryImage] : [],
    price: mainPrice,
    mainPrice,
    minPrice: mainPrice,
    maxPrice: mainPrice,
    hasVariablePricing: false,
    unitLabel,
    priceToken: unitLabel,
    category,
    shopBy,
    occasion: shopBy.occasion ?? [],
    style: shopBy.style ?? [],
    fabric: shopBy.fabric ?? [],
    colour: toArray(raw.colour ?? raw.color ?? raw.colours),
    size: toArray(raw.size ?? raw.sizes),
    isNewIn: raw.isNewIn === true || raw.newIn === true,
    publishedAt: toDate(raw.publishedAt ?? raw.firstPublishedAt),
    options,
    variants,
    aliases: toArray(raw.aliases),
    keywords: toArray(raw.keywords),
  };

  product.searchText = buildSearchText(product);
  return product;
}

function buildSearchText(product) {
  return normaliseText(
    [
      product.name,
      ...product.category,
      ...product.occasion,
      ...product.style,
      ...product.fabric,
      ...Object.values(product.shopBy ?? {}).flat(),
      ...product.colour,
      ...product.aliases,
      ...product.keywords,
    ].join(" ")
  );
}

/** Options the visitor must resolve before a Closet line can exist. */
export function requiredOptions(product) {
  return (product?.options ?? []).filter((option) => option.required);
}

/**
 * True when nothing is left for the visitor to choose: either there
 * are no required options, or every required option has exactly one
 * possible value, or a selection has already been supplied.
 */
export function resolveSelections(product, selections = {}) {
  const missing = [];
  const resolved = {};

  (product?.options ?? []).forEach((option) => {
    const supplied = selections?.[option.name];
    if (supplied && option.values.includes(supplied)) {
      resolved[option.name] = supplied;
      return;
    }
    if (option.required && option.values.length === 1) {
      resolved[option.name] = option.values[0];
      return;
    }
    if (option.required) missing.push(option.name);
  });

  return { resolved, missing, isComplete: missing.length === 0 };
}

/** Stable key so identical product + options share one Closet line. */
export function closetLineKey(productId, selections = {}) {
  const entries = Object.entries(selections)
    .filter(([, value]) => value !== undefined && value !== null && value !== "")
    .map(([key, value]) => [String(key), String(value)])
    .sort(([a], [b]) => a.localeCompare(b));
  return entries.length ? `${productId}::${JSON.stringify(entries)}` : `${productId}::`;
}

/** The price a given set of selections resolves to. With single fixed pricing, this is always the main price. */
export function priceForSelections(product, selections = {}) {
  if (!product) return null;
  return product.mainPrice ?? product.price ?? product.minPrice;
}
