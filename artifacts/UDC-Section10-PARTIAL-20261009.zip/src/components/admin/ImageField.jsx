import { useState } from "react";
import { getImageUrl } from "../../cloudinary/cloudinary";
import { uploadImage } from "../../services/imageStorage";
import { imageValue } from "../../services/adminModel";
import Button from "../common/Button";

export default function ImageField({ id, value, onChange, multiple = false, setUploading, maxImages = 8 }) {
  const [error, setError] = useState("");
  const [guidance, setGuidance] = useState("");
  const [busy, setBusy] = useState(false);
  const images = multiple ? (Array.isArray(value) ? value : value ? [value] : []) : value ? [value] : [];

  async function upload(event) {
    const selected = Array.from(event.target.files || []);
    event.target.value = "";
    if (!selected.length) return;
    setError("");
    setGuidance(selected.some(file => file.size > 2.5 * 1024 * 1024) ? "Large image selected — it can upload, but a smaller optimized source may load faster for customers." : "");
    if (selected.some(file => !["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 4 * 1024 * 1024)) {
      setError("Choose JPEG, PNG or WebP images smaller than 4 MB."); return;
    }
    if (multiple && images.length + selected.length > maxImages) {
      setError(`Use up to ${maxImages} photos for this record.`); return;
    }
    setBusy(true); setUploading(true);
    const next = [...images];
    try {
      for (const file of selected) {
        const image = await uploadImage(file);
        next.push({ ...image, alt: "" });
        onChange(multiple ? [...next] : image);
      }
    } catch (error) {
      setError((error.message || "The upload could not finish.") + " Successfully uploaded photos remain below.");
    } finally {
      setBusy(false); setUploading(false);
    }
  }

  function changeImage(index, patch) {
    const next = images.map((image, i) => i === index ? { ...imageValue(image), ...patch } : image);
    onChange(multiple ? next : next[0]);
  }

  function move(index, offset) {
    const target = index + offset;
    if (target < 0 || target >= images.length) return;
    const next = [...images];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  }

  return <div className="admin-stack">
    <input id={id} type="file" accept="image/jpeg,image/png,image/webp" multiple={multiple} disabled={busy} onChange={upload} />
    {busy && <p role="status">Uploading photos…</p>}
    {error && <p role="alert" className="field__error">{error}</p>}
    {guidance && !error && <p role="status" className="field__hint">{guidance}</p>}
    <div className="admin-image-grid">{images.map((raw, index) => {
      const image = imageValue(raw);
      return <div className="admin-image" key={`${image.publicId || image.url || "photo"}-${index}`}>
        <img src={image.publicId ? getImageUrl(image.publicId, "c_limit,w_520,h_650,q_auto,f_auto") : image.url} alt={image.alt || "Uploaded photo " + (index + 1)} />
        <label htmlFor={id + "-alt-" + index}>Photo {index + 1} description</label>
        <input id={id + "-alt-" + index} value={image.alt || ""} maxLength={250} onChange={event => changeImage(index, { alt: event.target.value })} />
        <div className="admin-actions">
          {multiple && index > 0 && <Button variant="ghost" onClick={() => onChange([images[index], ...images.filter((_, i) => i !== index)])}>Make cover</Button>}
          {multiple && index > 0 && <Button variant="ghost" onClick={() => move(index, -1)} aria-label={`Move photo ${index + 1} earlier`}>Move earlier</Button>}
          {multiple && index < images.length - 1 && <Button variant="ghost" onClick={() => move(index, 1)} aria-label={`Move photo ${index + 1} later`}>Move later</Button>}
          <Button variant="ghost" onClick={() => onChange(multiple ? images.filter((_, i) => i !== index) : null)}>Remove photo {index + 1}</Button>
        </div>
      </div>;
    })}</div>
    {multiple && <p className="field__hint">{images.length} of {maxImages} photos uploaded. Photo 1 is the primary image shown on the homepage.</p>}
    <p className="field__hint">Removing a photo here removes it from this record when saved. The stored photo is retained until the site owner removes it from image storage.</p>
  </div>;
}
